#author = "Chang Liu"
#copyright = "Copyright 2019, Nanjing University, njuRS"
#license = "GPL"
#version = "0.2"
#maintainer = "Chang Liu"
#email = "changliu811@gmail.com"
#status = "Production"
#description = "built-up areas mapping"

#this step is to clip the NTL images based on the Landsat-8.

import arcpy,os,sys
import os
import shutil
from arcpy import env
from arcpy.sa import *

if arcpy.CheckExtension('Spatial') == 'Available':
    arcpy.AddMessage('Checking out Spatial')
    arcpy.CheckOutExtension('Spatial')
else:
    arcpy.AddError('Unable to get spatial analyst extension')
    arcpy.AddMessage(arcpy.GetMessages(0))
    sys.exit(0)

def file_name(file_dir): 
    for root, dirs, files in os.walk(file_dir):
        print(root) 
        print(dirs) 
        print(files) 



NTLpath = r'Z:\Pakistan_2017\NTL_image'
TOA_cpsbandsPath =  r'Z:\Pakistan_2017\image_mapping_TOA_compositebands'
clip_NTLpath = r'Z:\Pakistan_2017\image_mapping_clipNTL' 


if os.path.exists(clip_NTLpath)==False:
        os.mkdir(clip_NTLpath)



for root_TOA, dirs_TOA, files_TOA in os.walk(TOA_cpsbandsPath):
    for name_TOA in files_TOA:
        if "copyRaster" in name_TOA and name_TOA.endswith ('.tif'):     
            print 'ImageFile:',name_TOA
            pathL8_compositebands = os.path.join(root_TOA, name_TOA)            
            spatial_ref = arcpy.Describe(pathL8_compositebands).spatialReference
            coodinate = "{0}".format(spatial_ref.name)
            month_name = name_TOA.split('_')[5][4:6]
            print 'month:',month_name
            NTLfilePath = clip_NTLpath + "//NTL_" + name_TOA.split('TOA_')[1][0:40]+ '.tif'
            if os.path.exists(NTLfilePath)==False:
                env.workspace= NTLpath
                for roots_NTL,dirs_NTL,files_NTL in os.walk(NTLpath):
                    for dir_NTL in dirs_NTL:
                        month_NTL = dir_NTL.split('-')[0][14:16]
                        if month_name in month_NTL:
                            #print dir_NTL
                            select_NTL = os.path.join(roots_NTL, dir_NTL)
                            #print select_NTL
                            env.workspace= select_NTL
                            rasters=arcpy.ListRasters('*', 'tif')
                            for NTL_raster in rasters:
                                if 'rade9h' in NTL_raster:
                                    print NTL_raster
                                    NTL_name = NTL_raster.split('_vcmslcfg')[0] + '.tif'                            
                                    arcpy.env.extent = pathL8_compositebands
                                    arcpy.env.mask = pathL8_compositebands
                                    arcpy.env.snapRaster = pathL8_compositebands
                                    NTL_ExtractByMask = ExtractByMask(NTL_raster, pathL8_compositebands)
                                    arcpy.ProjectRaster_management(NTL_ExtractByMask, clip_NTLpath + "//NTL_" + name_TOA.split('TOA_')[1][0:40]+ '.tif',\
                                                   spatial_ref, "BILINEAR", '30',\
                                                   "#", "#", "#")          


       