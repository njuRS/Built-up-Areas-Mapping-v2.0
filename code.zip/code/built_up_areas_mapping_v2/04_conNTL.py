#author = "Chang Liu"
#copyright = "Copyright 2019, Nanjing University, njuRS"
#license = "GPL"
#version = "0.2"
#maintainer = "Chang Liu"
#email = "changliu811@gmail.com"
#status = "Production"
#description = "built-up areas mapping"

#Noted that if using the month-average NTL images, this step helps you process the NTL images if the NTL radiance <0.

import arcpy,os,sys
import os
from arcpy import env
from arcpy.sa import *


clip_NTLpath = r'Z:\Pakistan_2017\image_mapping_clipNTL' 
monthNTLPath = r'Z:\Pakistan_2017\image_mapping_monthNTL'

env.workspace  = clip_NTLpath
rasters=arcpy.ListRasters('*', 'tif')

for raster in rasters:
    print raster
    savePath = monthNTLPath  + '//' +  raster
    if os.path.exists(savePath)==False:
        clip_NTLRaster = Con(Raster(raster)<0, 0,raster)    
        clip_NTLRaster.save(savePath) 
        arcpy.Delete_management("in_memory")   