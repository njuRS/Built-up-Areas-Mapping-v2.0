#author = "Chang Liu"
#copyright = "Copyright 2019, Nanjing University, njuRS"
#license = "GPL"
#version = "0.2"
#maintainer = "Chang Liu"
#email = "changliu811@gmail.com"
#status = "Production"
#description = "built-up areas mapping"

#this step is to make MNDWI and NDVI based on the Landsat-8 imagery.
import arcpy,os,sys
import os
import shutil
from arcpy import env
from arcpy.sa import *

if arcpy.CheckExtension('Spatial') == 'Available':
    arcpy.AddMessage('Checking out Spatial')
    arcpy.CheckOutExtension('Spatial')
else:
    arcpy.AddError('Unable to get spatial analyst extension')
    arcpy.AddMessage(arcpy.GetMessages(0))
    sys.exit(0)



TOA_cpsbandsPath =  r'Z:\Pakistan_2017\image_mapping_TOA_compositebands'
maskPath = r'Z:\Pakistan_2017\image_mapping_masks'
if os.path.exists(maskPath)==False:
        os.mkdir(maskPath)


env.workspace= TOA_cpsbandsPath
env.overwriteOutput = True
rasters=arcpy.ListRasters('*', 'tif')
for raster in rasters:
    if 'copyRaster' in raster:
        print raster
        outputPath= maskPath + '\\'+ raster.split('_copyRaster')[0]
        if os.path.exists(outputPath)==False:
            os.mkdir(outputPath)
            blueband = Raster(raster + '\\Band_2')
            greenband = Raster(raster + '\\Band_3')
            redband = Raster(raster + '\\Band_4')
            nirband = Raster(raster + '\\Band_5')
            swir1 = Raster(raster + '\\Band_6')
            swir2 = Raster(raster + '\\Band_7')
  
            ndviRaster=Float(nirband - redband) / Float(redband + nirband)
            ndvi_filename = 'NDVI_' + raster
            ndviRaster.save(os.path.join(outputPath,ndvi_filename))

            MNDWIRaster = Float(greenband-swir1) / Float(greenband + swir1)
            MNDWI_filename = "MNDWI_" + raster
            MNDWIRaster.save(os.path.join(outputPath,MNDWI_filename))
                    
            arcpy.Delete_management("in_memory")
