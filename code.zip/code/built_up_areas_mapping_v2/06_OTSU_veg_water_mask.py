#author = "Chang Liu"
#copyright = "Copyright 2019, Nanjing University, njuRS"
#license = "GPL"
#version = "0.2"
#maintainer = "Chang Liu"
#email = "changliu811@gmail.com"
#status = "Production"
#description = "built-up areas mapping"

# this step is to make water and vegetation masks based on the otsu algorithm.

from skimage import data,filters,io
from skimage.filters import threshold_otsu
from skimage.util import img_as_ubyte
import os
import shutil
import sys
from osgeo import gdal, osr, gdal_array
import numpy as np


maskPath = r'Z:\Pakistan_2017\image_mapping_masks'
TOA_cpsbandsPath =  r'Z:\Pakistan_2017\image_mapping_TOA_compositebands'


os.chdir(TOA_cpsbandsPath)
for root_image,dirs,files in os.walk(TOA_cpsbandsPath):
    for file_image in files:
        if 'copyRaster' in file_image and file_image.endswith('.tif'):
            name = file_image.split('_copyRaster')[0]
            L8Path = os.path.join(root_image,file_image)
            print L8Path
            ds = gdal.Open(L8Path) 
            geotransform = ds.GetGeoTransform()  
            proj = ds.GetProjection()  
            band_refer = ds.GetRasterBand(1)  
            nodata = band_refer.GetNoDataValue()
            data_refer = band_refer.ReadAsArray()  
            xNum = data_refer.shape[1]     
            yNum = data_refer.shape[0]  

            os.chdir(maskPath)
            for root_mask,dirs,files in os.walk(maskPath):
                for dirs_mask in dirs:
                    if name in dirs_mask:
                        otsuPath = os.path.join( root_mask,dirs_mask)
                        print otsuPath
                        for root_otsu,dirs,files in os.walk(otsuPath):                           
                            for file_otsu in files:
                                if 'NDVI' in file_otsu and file_otsu.endswith('.tif'):
                                    NDVIPath = os.path.join(root_otsu,file_otsu)
                                    #print NDVIPath
                                    NDVI_filename = '_NDVI_otsu'
                                if 'MNDWI' in file_otsu and file_otsu.endswith('.tif'):
                                    MNDWIPath = os.path.join(root_otsu,file_otsu)
                                    #print MNDWIPath
                                    MNDWI_filename = '_MNDWI_otsu'

                        NDVIotsuPath = otsuPath + '\\' + name +  NDVI_filename + '.tif'
                        MNDWIotsuPath = otsuPath + '\\' + name + MNDWI_filename + '.tif'

                        if os.path.exists(NDVIotsuPath)==False:
                            print 'calculatingNDVI..'
                            NDVI_img = io.imread(NDVIPath)
                            rows,cols=NDVI_img.shape
                            for i in range(rows):
                                for j in range(cols):
                                    if (NDVI_img[i,j]<-1):
                                        NDVI_img[i,j]=-1;
                                    elif (NDVI_img[i,j]>1):
                                        NDVI_img[i,j]=1
                            NDVI_dst = img_as_ubyte(NDVI_img) #float to unit8
                            threshold_global_otsu = threshold_otsu(NDVI_dst)
                            global_otsu = NDVI_dst >= threshold_global_otsu
                            NDVI_mask = (global_otsu == False)
                            NDVI_data = NDVI_mask.astype(np.int)
                            driver = gdal.GetDriverByName('GTiff')
                            output_ds = driver.Create( NDVIotsuPath ,xNum,yNum,1,gdal.GDT_Float64)
                            output_ds.SetGeoTransform(geotransform)
                            output_ds.SetProjection(proj)
                            output_ds.GetRasterBand(1).WriteArray(NDVI_data)
                            output_ds.GetRasterBand(1).SetNoDataValue(0.0)
                            output_ds = None
                        if os.path.exists(MNDWIotsuPath)==False:
                            print 'calculatingMNDWI..'
                            MNDWI_img = io.imread(MNDWIPath)
                            rows,cols=MNDWI_img.shape
                            for i in range(rows):
                                for j in range(cols):
                                    if (MNDWI_img[i,j]<-1):
                                        MNDWI_img[i,j]=-1;
                                    elif (MNDWI_img[i,j]>1):
                                        MNDWI_img[i,j]=1

                            MNDWI_dst = img_as_ubyte(MNDWI_img) #float to unit8
                            threshold_global_otsu = threshold_otsu(MNDWI_dst)
                            global_otsu = MNDWI_dst >= threshold_global_otsu
                            MNDWI_mask = (global_otsu == False)
                            MNDWI_data = MNDWI_mask.astype(np.int)
                            driver = gdal.GetDriverByName('GTiff')
                            output_ds = driver.Create(MNDWIotsuPath ,xNum,yNum,1,gdal.GDT_Float64)
                            output_ds.SetGeoTransform(geotransform)
                            output_ds.SetProjection(proj)
                            output_ds.GetRasterBand(1).WriteArray(MNDWI_data)
                            output_ds.GetRasterBand(1).SetNoDataValue(0.0)
                            output_ds = None






