#author = "Chang Liu"
#copyright = "Copyright 2019, Nanjing University, njuRS"
#license = "GPL"
#version = "0.2"
#maintainer = "Chang Liu"
#email = "changliu811@gmail.com"
#status = "Production"
#description = "built-up areas mapping"

#this step is to create training samples.
#Before running this step, you need to get the classification thresholds of Jenks natural breaks by using ArcGis.

import arcpy,os,sys
import os
import shutil
from arcpy import env
from arcpy.sa import *
import xlrd


if arcpy.CheckExtension('Spatial') == 'Available':
    arcpy.AddMessage('Checking out Spatial')
    arcpy.CheckOutExtension('Spatial')
else:
    arcpy.AddError('Unable to get spatial analyst extension')
    arcpy.AddMessage(arcpy.GetMessages(0))
    sys.exit(0)

clip_NTLpath= r'Z:\Pakistan_2017\image_mapping_monthNTL' 
maskPath = r'Z:\Pakistan_2017\image_mapping_masks'
trainpath = r'Z:\Pakistan_2017\image_mapping_trainsamples'
naturalbreakspath = r'Z:\Pakistan_2017\jenks_natural_breaks.xlsx'

if os.path.exists(trainpath )==False:
    os.mkdir(trainpath)

        
wb = xlrd.open_workbook(naturalbreakspath)
sheet = wb.sheet_by_index(0)
rows = sheet.nrows
for i in range(1,rows):
    datas = sheet.row_values(i)
    pathrow = str(int(datas[0]))
    print pathrow
    print 'datas[1]',datas[1]
    print 'datas[2]',datas[2]
    print 'datas[3]',datas[3]
    for root,dirs,files in os.walk(clip_NTLpath):
        for file_NTL in files:
            if file_NTL.endswith('.tif') and pathrow in file_NTL:
                NTLimg_Path = os.path.join(root,file_NTL)
                NTLname = file_NTL.split('_')[3]
                #print NTLname
                #print NTLimg_Path
                os.chdir(maskPath)
                for root,dirs,files in os.walk(maskPath):
                    for file_mask in files:
                        if pathrow in file_mask and 'NDVI_otsu' in file_mask and file_mask.endswith ('.tif'):
                            vegMask_Path = os.path.join(root,file_mask)
                            print vegMask_Path
                        if pathrow in file_mask and 'MNDWI_otsu' in file_mask and file_mask.endswith ('.tif'):
                            waterMask_Path = os.path.join(root,file_mask)   
                            print waterMask_Path       
                os.chdir(trainpath)
                outputPath= trainpath + '\\'+ file_NTL.split('NTL_')[1][0:40]
                if os.path.exists(outputPath)==False:
                    #print outputPath 
                    os.mkdir(outputPath)
                    field = "VALUE"
                    as_remapString = datas[1]
                    arcpy.Reclassify_3d(NTLimg_Path, field, as_remapString, outputPath + '\\' + pathrow +'_built_up_potential_trainsample.tif','NODATA')
                    nonas_remapString = datas[2]
                    arcpy.Reclassify_3d(NTLimg_Path, field, nonas_remapString, outputPath + '\\' + pathrow +'_nonbuilt_up_trainsample.tif','NODATA')
                    Target_remapString = datas[3]
                    arcpy.Reclassify_3d(NTLimg_Path, field, Target_remapString, outputPath + '\\' + pathrow +'_target_area_NTL.tif', 'NODATA')


                    for roots, dirs, files in os.walk(outputPath):
                        for file_bu in files:
                            if 'built_up_potential_trainsample' in file_bu and file_bu.endswith ('.tif'):
                                train_bu_Path = os.path.join(roots,file_bu)
                                print train_bu_Path
                                train_bu = Raster(vegMask_Path) & Raster(waterMask_Path) & Raster(train_bu_Path)
                                train_bu_filename =  pathrow + '_built_up_trainsample.tif'
                                train_bu.save(os.path.join(outputPath,train_bu_filename))

