#author = "Chang Liu"
#copyright = "Copyright 2019, Nanjing University, njuRS"
#license = "GPL"
#version = "0.2"
#maintainer = "Chang Liu"
#email = "changliu811@gmail.com"
#status = "Production"
#description = "built-up areas mapping"

# this step is to convert the trainsamples[TIF] to trainsamples[shp]



import arcpy,os,sys
import os
import shutil
from arcpy import env
from arcpy.sa import *

if arcpy.CheckExtension('Spatial') == 'Available':
    arcpy.AddMessage('Checking out Spatial')
    arcpy.CheckOutExtension('Spatial')
else:
    arcpy.AddError('Unable to get spatial analyst extension')
    arcpy.AddMessage(arcpy.GetMessages(0))
    sys.exit(0)

trainpath = r'Z:\Pakistan_2017\image_mapping_trainsamples'

for root, dirs, files in os.walk(trainpath):
    for ts_dir in dirs:
        print ts_dir
        ts_path = os.path.join(root, ts_dir)
        print ts_path
        env.workspace= ts_path
        env.overwriteOutput = True
        rasters=arcpy.ListRasters('*', 'tif')
        for raster in rasters:
            if 'built_up_trainsample' in raster or 'nonbuilt_up_trainsample' in raster:
                print raster.split('.tif')[0]
                outPolygons = ts_path + '\\' +  raster.split('.tif')[0] + '.shp'
                field = "VALUE"
                arcpy.RasterToPolygon_conversion(raster, outPolygons,"NO_SIMPLIFY", field)
                dissolveFields = 'GRIDCODE'
                outFeatureClass = ts_path + '\\' + raster.split('.tif')[0] + '_dissolve.shp'
                arcpy.Dissolve_management(outPolygons, outFeatureClass, dissolveFields)
                arcpy.Delete_management("in_memory")






#env.workspace= outputPath
#env.overwriteOutput = True
#rasters=arcpy.ListRasters('*', 'tif')
#for raster in rasters:
#    if 'built_up_trainsample' in raster or 'nonbuilt_up_trainsample' in raster:
#        print raster.split('.tif')[0]
#        outPolygons = trainpath + '\\' +  raster.split('.tif')[0] + '.shp'
#        field = "VALUE"
#        arcpy.RasterToPolygon_conversion(raster, outPolygons,"NO_SIMPLIFY", field)
#        dissolveFields = 'GRIDCODE'
#        outFeatureClass = outputPath + '\\' + raster.split('.tif')[0] + '_dissolve.shp'
#        arcpy.Dissolve_management(outPolygons, outFeatureClass, dissolveFields)
#        arcpy.Delete_management("in_memory")