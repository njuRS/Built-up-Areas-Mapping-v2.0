#author = "Chang Liu"
#copyright = "Copyright 2019, Nanjing University, njuRS"
#license = "GPL"
#version = "0.1"
#maintainer = "Chang Liu"
#email = "changliu811@gmail.com"
#status = "Production"
#description = "artificial surface mapping"

import arcpy,os,sys
import os
import shutil
from arcpy import env
from arcpy.sa import *

if arcpy.CheckExtension('Spatial') == 'Available':
    arcpy.AddMessage('Checking out Spatial')
    arcpy.CheckOutExtension('Spatial')
else:
    arcpy.AddError('Unable to get spatial analyst extension')
    arcpy.AddMessage(arcpy.GetMessages(0))
    sys.exit(0)


trainpath = r'Z:\Pakistan_2017\test\image_trainingpoints'
TOA_cpsbandsPath =  r'Z:\Pakistan_2017\test\image_TOA_compositebands'
SVMpath = r'Z:\Pakistan_2017\test\image_SVMtraining' 
maskPath = r'Z:\Pakistan_2017\test\image_mask'
resultpath = r'Z:\Pakistan_2017\test\0image_result'

if os.path.exists(resultpath)==False:
        os.mkdir(resultpath)


for root, dirs, files in os.walk(trainpath):
    for file_trainsample in files:
        if 'merge_trainsample' in file_trainsample and file_trainsample.endswith('.shp'):
            train_pathrow = file_trainsample.split('_')[0]
            trainsamples = os.path.join(root, file_trainsample)
            print 'trainsamples', trainsamples
            print 'train_pathrow', train_pathrow

            for root, dirs, files in os.walk(TOA_cpsbandsPath):
                for file_image in files:
                    if "copyRaster" in file_image and train_pathrow in file_image.split('_')[4] and file_image.endswith ('.tif'):
                        print "file_image",file_image
                        L8_compositebands = os.path.join(root, file_image)
                        arcpy.gp.TrainSupportVectorMachineClassifier(L8_compositebands, trainsamples, SVMpath + '//' + train_pathrow + '_svm_classification.ecd')
                        classifiedraster = ClassifyRaster(L8_compositebands ,SVMpath + '//' + train_pathrow + '_svm_classification.ecd')
                        outputPath = resultpath + '//' + file_image.split('_copyRaster')[0]
                        print 'outputPath',outputPath
                        os.mkdir(outputPath)    
                        os.chdir(resultpath)                   
                        tempraster_filename = 'tempresult_bu_' + file_image.split('_copyRaster')[0] + '.tif'
                        classifiedraster.save(os.path.join(outputPath,tempraster_filename))
            for tempsvm_root, dirs, files in os.walk(outputPath):
                for tempsvm_name in files:
                    if 'tempresult'in tempsvm_name and train_pathrow in tempsvm_name and tempsvm_name.endswith ('.tif'):
                        temp_svm_raster = os.path.join(tempsvm_root, tempsvm_name)
                        print 'temp_svm_raster',temp_svm_raster

            for target_root, dirs, files in os.walk(trainpath):
                for file_targetNTL in files:
                    if 'target_area_NTL'in file_targetNTL and train_pathrow in file_targetNTL and file_targetNTL.endswith ('.tif'):
                        targetraster = os.path.join(target_root, file_targetNTL)
                        print 'targetraster',targetraster

            for root,dirs,files in os.walk(maskPath):
                for file_MNDWI in files:
                    if 'MNDWI_otsu' in file_MNDWI and train_pathrow in file_MNDWI and file_MNDWI.endswith('.tif'):
                        MNDWI = os.path.join(root,file_MNDWI)

            result = Raster(temp_svm_raster) & Raster(targetraster)& Raster(MNDWI)
            result_filename = 'result_bu_' + file_image.split('_copyRaster')[0]+ '.tif'
            result.save(os.path.join(outputPath,result_filename))
            arcpy.Delete_management("in_memory")